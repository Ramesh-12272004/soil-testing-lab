import streamlit as st
import numpy as np
import pandas as pd
from io import BytesIO
from docx import Document
from docx.shared import Inches
from datetime import datetime

def run():
    st.subheader("🧪 In-situ Density by Core Cutter Method")
    st.caption("IS 2720: Part 29: 1975, reaffirmed 1995")

    # ---------------- PROCEDURE ----------------
    with st.expander("📘 View Detailed Procedure"):
        st.markdown("""
### Objective
To determine the bulk and dry density of soil in-situ using the core cutter method.

### Formulae
- Bulk Density: ρb = W / V
- Moisture Content: w = [(Ww - Wd) / Wd] × 100
- Dry Density: ρd = ρb / (1 + w/100)

Where:  
- W = weight of soil sample (g)  
- V = volume of core cutter (cm³)  
- Ww = wet weight of soil (g)  
- Wd = dry weight of soil (g)  

### Steps
1. Measure the height and internal diameter of the core cutter.  
2. Excavate a hole in the soil and insert the core cutter.  
3. Trim excess soil and weigh the cutter with soil.  
4. Take a representative wet soil sample for moisture determination.  
5. Oven-dry the sample and weigh it.  
6. Compute bulk density, moisture content, and dry density.  
7. Assess soil compaction suitability.
""")

    # ---------------- INPUTS ----------------
    st.markdown("### 📏 Core Cutter Dimensions")
    h = st.number_input("Height of Core Cutter (cm)", value=12.8, min_value=0.1, key="cc_h")
    d = st.number_input("Internal Diameter of Core Cutter (cm)", value=10.0, min_value=0.1, key="cc_d")

    volume = np.pi * (d / 2) ** 2 * h
    st.info(f"Calculated Volume of Core Cutter = {volume:.2f} cm³")

    st.markdown("### ⚖️ Weight Measurements")
    wt_empty = st.number_input("Weight of Empty Core Cutter (g)", value=0.0, min_value=0.0, key="cc_wt_empty")
    wt_full = st.number_input("Weight of Core Cutter with Soil (g)", value=0.0, min_value=wt_empty, key="cc_wt_full")
    wt_container = st.number_input("Weight of Empty Moisture Container (g)", value=0.0, min_value=0.0, key="cc_wt_container")
    wt_wet = st.number_input("Weight of Container + Wet Soil (g)", value=0.0, min_value=wt_container, key="cc_wt_wet")
    wt_dry = st.number_input("Weight of Container + Dry Soil (g)", value=0.0, min_value=wt_container, key="cc_wt_dry")

    # ---------------- CALCULATION ----------------
    if st.button("📊 Calculate Core Cutter Results"):

        # Validate inputs
        if not (h>0 and d>0 and wt_full>wt_empty and wt_wet>wt_container and wt_dry>wt_container):
            st.error("Please enter valid positive and consistent input values.")
            return None

        try:
            # Bulk density
            wt_soil = wt_full - wt_empty
            bulk_density = wt_soil / volume

            # Moisture content
            Wd = wt_dry - wt_container
            Ww = wt_wet - wt_container
            moisture_content = ((Ww - Wd) / Wd) * 100 if Wd>0 else 0.0

            # Dry density
            dry_density = bulk_density / (1 + moisture_content/100)

            # Display results
            st.markdown("### Results")
            st.info(f"Bulk Density = {bulk_density:.2f} g/cc")
            st.info(f"Moisture Content = {moisture_content:.2f}%")
            st.success(f"Dry Density = {dry_density:.2f} g/cc")

            # Suitability
            st.markdown("### Suitability")
            if dry_density < 1.4:
                suitability = "Low compaction — may not be suitable for subgrade."
                st.warning(suitability)
            elif 1.4 <= dry_density < 1.75:
                suitability = "Moderately compacted soil — suitable for general fill."
                st.info(suitability)
            else:
                suitability = "Well compacted soil — suitable for base/subbase layers."
                st.success(suitability)

            # ---------------- WORD REPORT ----------------
            doc = Document()
            doc.add_heading("Core Cutter Method Report", 0)
            doc.add_paragraph(f"Date: {datetime.now().strftime('%d-%m-%Y')}")
            doc.add_heading("Procedure", level=1)
            doc.add_paragraph("""
1. Measure core cutter dimensions.  
2. Insert cutter into soil and trim excess.  
3. Weigh cutter with soil.  
4. Take wet soil sample for moisture determination.  
5. Oven-dry and weigh the sample.  
6. Compute bulk density, moisture content, and dry density.  
7. Assess soil suitability.
""")
            doc.add_heading("Formulae", level=1)
            doc.add_paragraph("Bulk Density: ρb = W / V")
            doc.add_paragraph("Moisture Content: w = [(Ww - Wd)/Wd] × 100")
            doc.add_paragraph("Dry Density: ρd = ρb / (1 + w/100)")

            # Input Table
            doc.add_heading("Input Data", level=1)
            table = doc.add_table(rows=1, cols=5)
            hdr_cells = table.rows[0].cells
            hdr_cells[0].text = "Parameter"
            hdr_cells[1].text = "Height (cm)"
            hdr_cells[2].text = "Diameter (cm)"
            hdr_cells[3].text = "Weight (g)"
            hdr_cells[4].text = "Comments"

            input_params = [
                ("Empty Cutter", "", "", wt_empty, ""),
                ("Cutter + Soil", "", "", wt_full, ""),
                ("Empty Container", "", "", wt_container, ""),
                ("Container + Wet Soil", "", "", wt_wet, ""),
                ("Container + Dry Soil", "", "", wt_dry, "")
            ]

            for p, h_val, d_val, w_val, cmt in input_params:
                row_cells = table.add_row().cells
                row_cells[0].text = str(p)
                row_cells[1].text = str(h_val)
                row_cells[2].text = str(d_val)
                row_cells[3].text = str(w_val)
                row_cells[4].text = str(cmt)

            # Results Table
            doc.add_heading("Calculated Results", level=1)
            res_table = doc.add_table(rows=1, cols=2)
            res_table.rows[0].cells[0].text = "Parameter"
            res_table.rows[0].cells[1].text = "Value"

            results_list = [
                ("Core Cutter Volume (cm³)", round(volume,2)),
                ("Bulk Density (g/cc)", round(bulk_density,2)),
                ("Moisture Content (%)", round(moisture_content,2)),
                ("Dry Density (g/cc)", round(dry_density,2)),
                ("Suitability", suitability)
            ]

            for param, val in results_list:
                row_cells = res_table.add_row().cells
                row_cells[0].text = str(param)
                row_cells[1].text = str(val)

            buffer = BytesIO()
            doc.save(buffer)
            buffer.seek(0)

            st.download_button(
                "📥 Download Core Cutter Word Report",
                data=buffer,
                file_name="Core_Cutter_Report.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )

            # Return results for main app
            return {
                "Input Data": pd.DataFrame({
                    "Parameter": ["Height (cm)", "Diameter (cm)", "Wt Empty Cutter", "Wt Cutter + Soil",
                                  "Wt Container", "Wt Wet Soil", "Wt Dry Soil"],
                    "Value": [h, d, wt_empty, wt_full, wt_container, wt_wet, wt_dry]
                }),
                "Calculated Results": pd.DataFrame({
                    "Parameter": ["Volume (cm³)", "Bulk Density (g/cc)", "Moisture Content (%)", "Dry Density (g/cc)", "Suitability"],
                    "Value": [round(volume,2), round(bulk_density,2), round(moisture_content,2), round(dry_density,2), suitability]
                }),
                "Remarks": "In-situ density determined using Core Cutter Method."
            }

        except Exception as e:
            st.error(f"Error during calculation: {e}")
            return None

    return None