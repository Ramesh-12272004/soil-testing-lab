import streamlit as st
import numpy as np
import pandas as pd
from io import BytesIO, StringIO
from docx import Document
from docx.shared import Inches

def run():
    st.subheader("Specific Gravity by Density Bottle Method (IS 2720: Part 3, Sec 1: 1980)")

    # --- Procedure & Formula ---
    with st.expander("📝 Procedure & Formula", expanded=True):
        st.markdown("""
### Test Procedure:
1. Weigh the empty density bottle (W1).
2. Add dry soil and weigh the bottle (W2).
3. Fill the bottle with carbon tetrachloride (CCl₄) and weigh (W3).
4. Weigh the bottle with CCl₄ only (W4).
5. Calculate specific gravity (G) using the formula below.

### Formula (Text Version):
G = ((W2 - W1) × ((W4 - W1) / V)) / ((W4 - W1) - (W3 - W2))

Where:
- W1 = Weight of empty density bottle (g)
- W2 = Weight of bottle + dry soil (g)
- W3 = Weight of bottle + soil + CCl₄ (g)
- W4 = Weight of bottle + CCl₄ only (g)
- V  = Volume of density bottle (cm³)
""")

    # --- Session State Initialization ---
    if "sg_volume" not in st.session_state:
        st.session_state.sg_volume = 50.0
    if "sg_num_trials" not in st.session_state:
        st.session_state.sg_num_trials = 3

    # Bottle volume input
    st.session_state.sg_volume = st.number_input(
        "Volume of Density Bottle (cm³)",
        min_value=1.0,
        value=st.session_state.sg_volume
    )

    # Number of trials
    num_trials = st.number_input(
        "Number of Trials",
        min_value=1, max_value=10,
        value=st.session_state.sg_num_trials,
        step=1
    )

    if num_trials != st.session_state.sg_num_trials:
        st.session_state.sg_num_trials = num_trials
        st.session_state.sg_trial_inputs = [{"W1":0,"W2":0,"W3":0,"W4":0} for _ in range(num_trials)]

    if "sg_trial_inputs" not in st.session_state:
        st.session_state.sg_trial_inputs = [{"W1":0,"W2":0,"W3":0,"W4":0} for _ in range(num_trials)]
    while len(st.session_state.sg_trial_inputs) < num_trials:
        st.session_state.sg_trial_inputs.append({"W1":0,"W2":0,"W3":0,"W4":0})
    st.session_state.sg_trial_inputs = st.session_state.sg_trial_inputs[:num_trials]

    # --- Input fields per trial ---
    st.markdown("### Enter Data for Each Trial")
    for i in range(num_trials):
        st.markdown(f"#### Trial {i+1}")
        col1, col2 = st.columns(2)
        with col1:
            st.session_state.sg_trial_inputs[i]["W1"] = st.number_input(f"W1 (Empty) [{i+1}]", value=st.session_state.sg_trial_inputs[i]["W1"], key=f"sg_W1_{i}")
            st.session_state.sg_trial_inputs[i]["W2"] = st.number_input(f"W2 (Bottle + Dry Soil) [{i+1}]", value=st.session_state.sg_trial_inputs[i]["W2"], key=f"sg_W2_{i}")
        with col2:
            st.session_state.sg_trial_inputs[i]["W3"] = st.number_input(f"W3 (Bottle + Soil + CCl₄) [{i+1}]", value=st.session_state.sg_trial_inputs[i]["W3"], key=f"sg_W3_{i}")
            st.session_state.sg_trial_inputs[i]["W4"] = st.number_input(f"W4 (Bottle + CCl₄) [{i+1}]", value=st.session_state.sg_trial_inputs[i]["W4"], key=f"sg_W4_{i}")

    # --- Save Inputs CSV ---
    if st.button("💾 Save Inputs"):
        df_save = pd.DataFrame(st.session_state.sg_trial_inputs)
        df_save.insert(0, "Trial", range(1,len(df_save)+1))
        buffer = StringIO()
        df_save.to_csv(buffer,index=False)
        buffer.seek(0)
        st.download_button("📥 Download Input Data as CSV", data=buffer.getvalue(), file_name="specific_gravity_inputs.csv", mime="text/csv")

    # --- Calculate Specific Gravity ---
    if st.button("Calculate Specific Gravity"):
        results = []
        valid_G_list = []
        V = st.session_state.sg_volume
        if V <= 0:
            st.error("Volume of density bottle must be > 0")
            return None

        for i, trial in enumerate(st.session_state.sg_trial_inputs):
            W1, W2, W3, W4 = trial["W1"], trial["W2"], trial["W3"], trial["W4"]
            # Validate input relationships
            if not (W1>=0 and W2>=0 and W3>=0 and W4>=0 and W2>W1 and W4>W1 and W3>=W2):
                st.warning(f"Trial {i+1}: Invalid inputs.")
                results.append({"Trial": i+1, "Gc": None, "G": None, "Error": "Invalid inputs"})
                continue
            try:
                Gc = (W4 - W1) / V
                denom = (W4 - W1) - (W3 - W2)
                if denom != 0:
                    G = (W2 - W1) * Gc / denom
                    valid_G_list.append(G)
                    results.append({"Trial": i+1, "Gc": round(Gc,3), "G": round(G,3), "Error": None})
                else:
                    results.append({"Trial": i+1, "Gc": round(Gc,3), "G": None, "Error": "Denominator zero"})
            except Exception as e:
                results.append({"Trial": i+1, "Gc": None, "G": None, "Error": str(e)})

        if valid_G_list:
            G_avg = sum(valid_G_list)/len(valid_G_list)
            st.markdown("### Results per Trial")
            df_results = pd.DataFrame(results)
            if 'Error' in df_results.columns and df_results['Error'].isnull().all():
                df_results = df_results.drop(columns=['Error'])
            st.dataframe(df_results.round(3))
            st.success(f"Average Specific Gravity (Gavg) = {G_avg:.3f}")

            # Soil type interpretation
            st.markdown("### Soil Type Interpretation")
            if G_avg < 2.60:
                soil_type = "Likely contains organic matter."
                st.warning(soil_type)
            elif 2.60 <= G_avg <= 2.67:
                soil_type = "Sand or most inorganic soils."
                st.success(soil_type)
            elif 2.67 < G_avg <= 2.78:
                soil_type = "Silty sand or clay."
                st.info(soil_type)
            else:
                soil_type = "Possibly dense clay or heavy minerals."
                st.info(soil_type)

            # --- Download Word Report ---
            if st.button("📄 Generate Word Report"):
                doc = Document()
                doc.add_heading("Specific Gravity Test Report (Density Bottle Method)",0)
                doc.add_paragraph(f"Bottle Volume: {V} cm³")
                doc.add_paragraph(f"Average Specific Gravity (Gavg) = {G_avg:.3f}")
                doc.add_paragraph(f"Soil Type: {soil_type}")
                doc.add_paragraph("Remarks: Determined using IS 2720 Part 3, Sec 1 with CCl₄.")
                doc.add_heading("Trial Data",level=1)
                table = doc.add_table(rows=1,cols=len(df_results.columns))
                hdr_cells = table.rows[0].cells
                for idx, col in enumerate(df_results.columns):
                    hdr_cells[idx].text = col
                for i in range(len(df_results)):
                    row_cells = table.add_row().cells
                    for j,col in enumerate(df_results.columns):
                        row_cells[j].text = str(df_results[col].iloc[i])
                buffer_word = BytesIO()
                doc.save(buffer_word)
                buffer_word.seek(0)
                st.download_button("📥 Download Word Report", data=buffer_word.getvalue(),
                                   file_name="Specific_Gravity_Report.docx",
                                   mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document")

            return {
                "Bottle Volume": V,
                "Trial Inputs": st.session_state.sg_trial_inputs,
                "Trial Results": df_results,
                "Average G": G_avg,
                "Soil Type": soil_type
            }

        else:
            st.error("No valid G values could be calculated. Check input data.")
            return None

    return None