import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from io import BytesIO, StringIO
from docx import Document
from docx.shared import Inches

def run():
    st.subheader("Liquid Limit - Casagrande Method (IS 2720 Part 5)")

    # --- Procedure and formulas section ---
    st.markdown("""
### 🧪 Test Procedure

1. Take a small quantity of air-dried soil and pass it through 425 µm sieve.
2. Place the soil in a cup and mix with water to form a uniform paste.
3. Fill the Casagrande cup with soil paste.
4. Use the standard Casagrande device to close the groove.
5. Count the number of blows required to close a 12.7 mm groove by 25 mm.
6. Repeat for at least 3–5 different moisture contents.
7. Record the number of blows and calculate moisture content for each trial.
8. Plot the **flow curve** (moisture content vs log(number of blows)).
9. Determine **Liquid Limit (LL)** corresponding to 25 blows on the curve.

### 📐 Formulas Used

**1. Moisture Content (w%)**  
w (%) = ((W2 - W3) / (W3 - W1)) * 100
Where:  
- W1 = Weight of empty cup (g)  
- W2 = Weight of cup + wet soil (g)  
- W3 = Weight of cup + dry soil (g)  

**2. Logarithmic Regression for Flow Curve**  
Moisture Content = a * log10(Number of Blows) + b
LL = a * log10(25) + b
""")

    # --- Helper function to calculate Moisture Content ---
    def calculate_moisture_content(w1, w2, w3):
        if w1==0.0 and w2==0.0 and w3==0.0: return 0.0
        if not (w2 >= w3 >= w1): return np.nan
        weight_of_water = w2 - w3
        weight_of_dry_soil = w3 - w1
        if weight_of_dry_soil <= 0: return np.nan
        return (weight_of_water / weight_of_dry_soil) * 100

    # --- Input section ---
    num_samples = st.number_input(
        "Number of Trials/Samples", min_value=2, max_value=10, value=4, key="num_samples_input"
    )

    if "trial_data" not in st.session_state:
        st.session_state.trial_data = {}
    # Add/remove trials based on num_samples
    for i in range(num_samples):
        if f"trial_{i+1}" not in st.session_state.trial_data:
            st.session_state.trial_data[f"trial_{i+1}"] = {
                "Number of Blows":0.0,
                "Weight of empty cup (g)":0.0,
                "Weight of cup + wet soil (g)":0.0,
                "Weight of cup + dry soil (g)":0.0,
                "Moisture Content (%)":0.0
            }
    keys_to_remove = [key for key in st.session_state.trial_data.keys() if int(key.split('_')[1]) > num_samples]
    for key in keys_to_remove:
        del st.session_state.trial_data[key]

    # --- Input fields ---
    for i in range(num_samples):
        trial_key = f"trial_{i+1}"
        with st.expander(f"Trial {i+1} Details", expanded=True):
            st.session_state.trial_data[trial_key]["Number of Blows"] = st.number_input(
                f"Number of Blows (Trial {i+1})", min_value=0.0,
                value=float(st.session_state.trial_data[trial_key]["Number of Blows"]),
                key=f"blows_{i+1}", format="%.1f"
            )
            st.session_state.trial_data[trial_key]["Weight of empty cup (g)"] = st.number_input(
                f"W1: Empty Cup (g)", min_value=0.0,
                value=float(st.session_state.trial_data[trial_key]["Weight of empty cup (g)"]),
                key=f"w1_{i+1}", format="%.2f"
            )
            st.session_state.trial_data[trial_key]["Weight of cup + wet soil (g)"] = st.number_input(
                f"W2: Cup + Wet Soil (g)", min_value=0.0,
                value=float(st.session_state.trial_data[trial_key]["Weight of cup + wet soil (g)"]),
                key=f"w2_{i+1}", format="%.2f"
            )
            st.session_state.trial_data[trial_key]["Weight of cup + dry soil (g)"] = st.number_input(
                f"W3: Cup + Dry Soil (g)", min_value=0.0,
                value=float(st.session_state.trial_data[trial_key]["Weight of cup + dry soil (g)"]),
                key=f"w3_{i+1}", format="%.2f"
            )

            # Calculate moisture content
            w1_val = st.session_state.trial_data[trial_key]["Weight of empty cup (g)"]
            w2_val = st.session_state.trial_data[trial_key]["Weight of cup + wet soil (g)"]
            w3_val = st.session_state.trial_data[trial_key]["Weight of cup + dry soil (g)"]
            mc = calculate_moisture_content(w1_val, w2_val, w3_val)
            st.session_state.trial_data[trial_key]["Moisture Content (%)"] = mc
            if np.isnan(mc):
                st.error(f"Trial {i+1}: Invalid Input")
            else:
                st.info(f"Moisture Content (Trial {i+1}) = {mc:.2f}%")

    st.markdown("---")

    # --- Save Inputs CSV ---
    if st.button("💾 Save Inputs CSV"):
        df_save = pd.DataFrame.from_dict(st.session_state.trial_data, orient='index')
        df_save.index.name = "Trial Key"
        df_save = df_save.reset_index().rename(columns={"index":"Trial"})
        buffer = StringIO()
        df_save.to_csv(buffer, index=False)
        buffer.seek(0)
        st.download_button("📥 Download Input Data CSV", data=buffer.getvalue(),
                           file_name="casagrande_inputs.csv", mime="text/csv")

    # --- Calculate Liquid Limit ---
    if st.button("Calculate Liquid Limit"):
        df = pd.DataFrame.from_dict(st.session_state.trial_data, orient='index').reset_index(drop=True)
        df_filtered = df[(df["Number of Blows"]!=0.0) & (~df["Moisture Content (%)"].isna()) & (df["Moisture Content (%)"]!=0.0)]
        if len(df_filtered)<2:
            st.error("Enter at least 2 valid data points to perform calculation.")
            return None
        # Regression (flow curve)
        df_sorted = df_filtered.sort_values("Number of Blows")
        x = np.log10(df_sorted["Number of Blows"].astype(float))
        y = df_sorted["Moisture Content (%)"].astype(float)
        coeffs = np.polyfit(x, y, 1)
        a, b = coeffs
        LL = a*np.log10(25) + b

        # Plot
        min_x_plot = min(x); max_x_plot = max(x)
        x_vals = np.linspace(min_x_plot, max_x_plot, 100)
        y_vals = a*x_vals+b
        fig, ax = plt.subplots(figsize=(8,5))
        ax.plot(x, y, 'ro', label='Observed Data')
        ax.plot(x_vals, y_vals, 'b-', label='Flow Curve')
        ax.plot(np.log10(25), LL, 'go', markersize=8, label=f'LL ({LL:.2f}%)')
        ax.vlines(np.log10(25), 0, LL, color='gray', linestyle='--')
        ax.hlines(LL, min(ax.get_xlim()), np.log10(25), color='gray', linestyle='--')
        ax.set_xlabel("Number of Blows (Log Scale)")
        ax.set_ylabel("Moisture Content (%)")
        ax.set_title("Casagrande Flow Curve")
        ax.legend(); ax.grid(True, which="both", ls="--", c='0.7')
        blow_ticks = [10, 15, 20, 25, 30, 40, 50]
        ax.set_xticks([np.log10(b) for b in blow_ticks])
        ax.set_xticklabels([str(b) for b in blow_ticks])
        st.pyplot(fig)
        st.success(f"Estimated Liquid Limit = {LL:.2f}%")

        img_buf = BytesIO(); fig.savefig(img_buf, format="png", bbox_inches="tight"); img_buf.seek(0)
        plt.close(fig)

        # --- Word Report ---
        if st.button("📄 Generate Word Report"):
            doc = Document()
            doc.add_heading("Liquid Limit Test Report (Casagrande Method)",0)
            doc.add_paragraph(f"Estimated Liquid Limit (LL) = {LL:.2f}%")
            doc.add_paragraph("Remarks: Liquid Limit is determined at 25 blows using the flow curve.")
            doc.add_heading("Trial Data",level=1)
            table = doc.add_table(rows=1,cols=len(df_sorted.columns))
            hdr_cells = table.rows[0].cells
            for idx,col in enumerate(df_sorted.columns):
                hdr_cells[idx].text = col
            for i in range(len(df_sorted)):
                row_cells = table.add_row().cells
                for j,col in enumerate(df_sorted.columns):
                    row_cells[j].text = str(df_sorted[col].iloc[i])
            doc.add_heading("Flow Curve",level=1)
            doc.add_picture(img_buf, width=Inches(6))
            buffer_word = BytesIO(); doc.save(buffer_word); buffer_word.seek(0)
            st.download_button("📥 Download Word Report", data=buffer_word.getvalue(),
                               file_name="Liquid_Limit_Report.docx",
                               mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document")

        return {
            "Test Data": df_sorted,
            "Flow Curve Graph": img_buf,
            "Liquid Limit (LL)": f"{LL:.2f}%",
            "Remarks": "Liquid Limit determined at 25 blows from flow curve."
        }

    return None