import streamlit as st
import math
import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO, StringIO
from docx import Document
from docx.shared import Inches

def run():
    st.subheader("Variable Head Permeability Test (IS 2720 Part 17:1986)")

    # --- Procedure & Formula ---
    with st.expander("📝 Procedure & Formula", expanded=True):
        st.markdown(r"""
This test is used for **fine-grained soils**.  
The coefficient of permeability \( k \) is calculated using the Variable Head method:

**Formula (Text Format):**

k = (2.3 × a × L / (A × t)) × log₁₀(h₁ / h₂)

Where:  
- \( a \) : Area of standpipe (cm²)  
- \( A \) : Cross-sectional area of soil specimen (cm²)  
- \( L \) : Length of specimen (cm)  
- \( t \) : Time interval (s)  
- \( h₁, h₂ \) : Initial and final heads (cm)
""")

    # --- Session State Initialization ---
    if "vh_num_trials" not in st.session_state:
        st.session_state.vh_num_trials = 3
    if "vh_a" not in st.session_state:
        st.session_state.vh_a = 1.0
    if "vh_A" not in st.session_state:
        st.session_state.vh_A = 50.0
    if "vh_L" not in st.session_state:
        st.session_state.vh_L = 10.0

    # Number of Trials
    num_trials = st.number_input(
        "Number of Trials",
        min_value=1, max_value=10,
        value=st.session_state.vh_num_trials,
        step=1
    )
    if num_trials != st.session_state.vh_num_trials:
        st.session_state.vh_num_trials = num_trials
        st.session_state.vh_trial_inputs = [{"h1":0.0,"h2":0.0,"t":0.0} for _ in range(num_trials)]

    # Initialize trial inputs
    if "vh_trial_inputs" not in st.session_state:
        st.session_state.vh_trial_inputs = [{"h1":0.0,"h2":0.0,"t":0.0} for _ in range(num_trials)]
    while len(st.session_state.vh_trial_inputs) < num_trials:
        st.session_state.vh_trial_inputs.append({"h1":0.0,"h2":0.0,"t":0.0})
    st.session_state.vh_trial_inputs = st.session_state.vh_trial_inputs[:num_trials]

    # Constant parameters
    with st.expander("Enter Constant Parameters"):
        col1, col2 = st.columns(2)
        with col1:
            st.session_state.vh_a = st.number_input("Area of Standpipe (a) in cm²", min_value=0.0001, value=st.session_state.vh_a)
            st.session_state.vh_A = st.number_input("Cross-sectional Area of Soil Sample (A) in cm²", min_value=0.01, value=st.session_state.vh_A)
        with col2:
            st.session_state.vh_L = st.number_input("Length of Soil Specimen (L) in cm", min_value=0.01, value=st.session_state.vh_L)

    # Trial inputs
    for i in range(num_trials):
        st.markdown(f"### Trial {i+1}")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.session_state.vh_trial_inputs[i]["h1"] = st.number_input(f"Initial Head h₁ (cm) - Trial {i+1}", min_value=0.0, value=st.session_state.vh_trial_inputs[i]["h1"])
        with col2:
            st.session_state.vh_trial_inputs[i]["h2"] = st.number_input(f"Final Head h₂ (cm) - Trial {i+1}", min_value=0.0, value=st.session_state.vh_trial_inputs[i]["h2"])
        with col3:
            st.session_state.vh_trial_inputs[i]["t"] = st.number_input(f"Time Interval (s) - Trial {i+1}", min_value=0.0, value=st.session_state.vh_trial_inputs[i]["t"])

    # --- Save Inputs ---
    if st.button("💾 Save Inputs"):
        input_data_for_save = [
            {"Parameter": "Area of Standpipe (a) cm²", "Value": st.session_state.vh_a},
            {"Parameter": "Cross-sectional Area (A) cm²", "Value": st.session_state.vh_A},
            {"Parameter": "Length of Soil Specimen (L) cm", "Value": st.session_state.vh_L},
            {"Parameter": "--- Trial Data ---", "Value": ""}
        ]
        for i, trial in enumerate(st.session_state.vh_trial_inputs):
            input_data_for_save.extend([
                {"Parameter": f"Trial {i+1} - h1", "Value": trial["h1"]},
                {"Parameter": f"Trial {i+1} - h2", "Value": trial["h2"]},
                {"Parameter": f"Trial {i+1} - t", "Value": trial["t"]}
            ])
        df_save = pd.DataFrame(input_data_for_save)
        buffer = StringIO()
        df_save.to_csv(buffer, index=False)
        buffer.seek(0)
        st.download_button("📥 Download Input Data as CSV", data=buffer.getvalue(), file_name="variable_head_inputs.csv", mime="text/csv")

    # --- Calculate Results ---
    if st.button("Calculate Permeability"):
        calculated_trials = []
        a = st.session_state.vh_a
        A = st.session_state.vh_A
        L = st.session_state.vh_L

        if not (a>0 and A>0 and L>0):
            st.error("Constant parameters must be positive.")
            return None

        for i, trial in enumerate(st.session_state.vh_trial_inputs):
            h1, h2, t = trial["h1"], trial["h2"], trial["t"]
            if not (h1>0 and h2>0 and t>0 and h1>h2):
                st.warning(f"Trial {i+1} invalid. Ensure h₁ > h₂ and all positive.")
                continue
            k = (2.3 * a * L) / (A * t) * math.log10(h1 / h2)
            calculated_trials.append({"Trial": i+1, "h1 (cm)":h1, "h2 (cm)":h2, "t (s)":t, "k (cm/s)":round(k,6)})

        if calculated_trials:
            df_results = pd.DataFrame(calculated_trials)
            st.dataframe(df_results, use_container_width=True)
            avg_k = df_results["k (cm/s)"].mean()
            st.success(f"Average Coefficient of Permeability: {avg_k:.6f} cm/s")

            # Soil classification
            if avg_k < 1e-7: soil_class = "Very low permeability (e.g., Clay)"
            elif avg_k < 1e-5: soil_class = "Low permeability (e.g., Silty Clay)"
            elif avg_k < 1e-3: soil_class = "Medium permeability (e.g., Silty Sand)"
            else: soil_class = "High permeability (e.g., Sand or Gravel)"
            st.info(f"**Soil Classification**: {soil_class}")

            # Plot k vs time
            fig, ax = plt.subplots(figsize=(8,5))
            ax.plot(df_results["t (s)"], df_results["k (cm/s)"], marker='o', color='green', linestyle='-')
            ax.set_xlabel("Time (s)")
            ax.set_ylabel("Permeability (k in cm/s)")
            ax.set_title("Permeability vs Time")
            ax.grid(True)
            st.pyplot(fig)
            img_buf = BytesIO()
            fig.savefig(img_buf, format="png", bbox_inches='tight')
            img_buf.seek(0)
            plt.close(fig)

            # --- Word Report ---
            if st.button("📥 Download Word Report"):
                doc = Document()
                doc.add_heading("Variable Head Permeability Test Report", 0)
                doc.add_paragraph(f"Area of Standpipe (a) cm²: {a}")
                doc.add_paragraph(f"Cross-sectional Area of Soil Sample (A) cm²: {A}")
                doc.add_paragraph(f"Length of Soil Specimen (L) cm: {L}")
                doc.add_paragraph(f"Average Coefficient of Permeability: {avg_k:.6f} cm/s")
                doc.add_paragraph(f"Soil Classification: {soil_class}")

                doc.add_heading("Trial Data", level=1)
                table = doc.add_table(rows=1, cols=len(df_results.columns))
                hdr_cells = table.rows[0].cells
                for i, col in enumerate(df_results.columns):
                    hdr_cells[i].text = col
                for _, row in df_results.iterrows():
                    row_cells = table.add_row().cells
                    for j, col in enumerate(df_results.columns):
                        row_cells[j].text = str(row[col])

                doc.add_heading("Permeability vs Time Plot", level=1)
                doc.add_picture(img_buf, width=Inches(6))

                buffer_word = BytesIO()
                doc.save(buffer_word)
                buffer_word.seek(0)
                st.download_button(
                    label="📥 Download Word Report",
                    data=buffer_word,
                    file_name="Variable_Head_Permeability_Report.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                )

            return {
                "Constant Parameters": {"a": a, "A": A, "L": L},
                "Trial Data": df_results,
                "Average k": avg_k,
                "Soil Classification": soil_class,
                "Permeability vs Time Graph": img_buf,
                "Remarks": "Variable Head Permeability Test results."
            }
        else:
            st.error("No valid trials processed. Ensure h₁>h₂ and all positive values.")
            return None

    return None