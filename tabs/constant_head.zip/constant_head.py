import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from io import BytesIO
from docx import Document
from docx.shared import Inches
from datetime import datetime

def run():

    st.header("🧪 Constant Head Permeability Test")
    st.caption("IS 2720 (Part 36): 1987")

    # ---------------- PROCEDURE ----------------
    with st.expander("📘 View Detailed Procedure"):
        st.markdown("""
### Objective
To determine the coefficient of permeability (k) of coarse-grained soil.

### Formula
k = (Q × L) / (A × h × t)

Where:
- Q = Volume collected (cm³)
- L = Length of specimen (cm)
- A = Area (cm²)
- h = Head difference (cm)
- t = Time (s)

### Steps
1. Prepare soil specimen.
2. Fix in permeameter.
3. Apply constant head.
4. Collect discharge for known time.
5. Calculate permeability.
""")

    # ---------------- INPUT ----------------
    trials = st.number_input("Number of Trials", 1, 10, 3)

    data = []

    for i in range(trials):
        st.subheader(f"Trial {i+1}")
        col1, col2, col3 = st.columns(3)

        with col1:
            L = st.number_input(f"Length L (cm) - T{i+1}", value=10.0, key=f"L{i}")
            A = st.number_input(f"Area A (cm²) - T{i+1}", value=50.0, key=f"A{i}")

        with col2:
            h = st.number_input(f"Head h (cm) - T{i+1}", value=20.0, key=f"h{i}")
            Q = st.number_input(f"Volume Q (cm³) - T{i+1}", value=500.0, key=f"Q{i}")

        with col3:
            t = st.number_input(f"Time t (s) - T{i+1}", value=60.0, key=f"t{i}")

        if L>0 and A>0 and h>0 and Q>0 and t>0:
            k = (Q * L) / (A * h * t)
        else:
            k = 0

        data.append([L, A, h, Q, t, k])

    # ---------------- CALCULATION ----------------
    if st.button("📊 Calculate"):

        df = pd.DataFrame(data, columns=[
            "Length (cm)", "Area (cm²)", "Head (cm)",
            "Volume (cm³)", "Time (s)", "k (cm/s)"
        ])

        df["k (m/s)"] = df["k (cm/s)"] / 100

        avg_k = df["k (cm/s)"].mean()

        st.subheader("📋 Results")
        st.dataframe(df.style.format(precision=5))

        st.success(f"Average Coefficient of Permeability = {avg_k:.5f} cm/s")

        # Soil Classification
        if avg_k > 1e-1:
            soil = "Gravel"
        elif avg_k > 1e-2:
            soil = "Coarse Sand"
        elif avg_k > 1e-3:
            soil = "Medium Sand"
        elif avg_k > 1e-4:
            soil = "Fine Sand"
        elif avg_k > 1e-6:
            soil = "Silt"
        else:
            soil = "Clay"

        st.info(f"Soil Classification: {soil}")

        # ---------------- GRAPH ----------------
        fig, ax = plt.subplots()
        ax.plot(range(1, trials+1), df["k (cm/s)"], marker='o')
        ax.set_xlabel("Trial Number")
        ax.set_ylabel("k (cm/s)")
        ax.set_title("Permeability vs Trial")
        ax.grid(True)
        st.pyplot(fig)

        image_stream = BytesIO()
        fig.savefig(image_stream, format="png")
        image_stream.seek(0)

        # ---------------- WORD REPORT ----------------
        doc = Document()
        doc.add_heading("Constant Head Permeability Test Report", 0)
        doc.add_paragraph("IS 2720 (Part 36): 1987")
        doc.add_paragraph(f"Date: {datetime.now().strftime('%d-%m-%Y')}")

        doc.add_heading("Procedure", level=1)
        doc.add_paragraph("""
1. Prepare soil specimen.
2. Apply constant head.
3. Collect discharge.
4. Compute permeability.
""")

        doc.add_heading("Formula", level=1)
        doc.add_paragraph("k = (Q × L) / (A × h × t)")

        doc.add_heading("Results", level=1)

        table = doc.add_table(rows=1, cols=len(df.columns))
        for i, col in enumerate(df.columns):
            table.rows[0].cells[i].text = col

        for _, row in df.iterrows():
            cells = table.add_row().cells
            for i, val in enumerate(row):
                cells[i].text = f"{val:.5f}"

        doc.add_paragraph(f"\nAverage k = {avg_k:.5f} cm/s")
        doc.add_paragraph(f"Soil Type: {soil}")

        doc.add_heading("Conclusion", level=1)
        doc.add_paragraph(
            f"The coefficient of permeability of the given soil is {avg_k:.5f} cm/s. "
            f"Hence, the soil is classified as {soil}."
        )

        doc.add_page_break()
        doc.add_picture(image_stream, width=Inches(5))

        buffer = BytesIO()
        doc.save(buffer)
        buffer.seek(0)

        st.download_button(
            "📥 Download Word Report",
            data=buffer,
            file_name="Constant_Head_Test_Report.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )

        return df

    return None