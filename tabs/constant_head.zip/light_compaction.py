import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd
import math
from io import BytesIO, StringIO
from docx import Document
from docx.shared import Inches

def run():
    st.subheader("🧪 Light Compaction Test (IS 2720 Part 7:1980)")

    st.markdown("""
    This test determines the **Optimum Moisture Content (OMC)** and **Maximum Dry Density (MDD)** using the standard Proctor method.

    **Required Inputs Per Trial:**
    - W1: Weight of empty cup
    - W2: Weight of cup + wet soil
    - W3: Weight of cup + dry soil
    - W4: Weight of mould + base plate
    - W5: Weight of mould + compacted soil + base plate
    """)

    st.markdown("""
### Key Formulas (Plain Text)

1. **Water Content (%)**  
   w(%) = ((W2 - W1) - (W3 - W1)) / (W3 - W1) × 100

2. **Wet Density (g/cm³)**  
   ρ_wet = (W5 - W4) / V_mould

3. **Dry Density (g/cm³)**  
   ρ_dry = ρ_wet / (1 + w/100)
""")

    # --- Session State Initialization ---
    if "lc_mould_dia" not in st.session_state: st.session_state.lc_mould_dia = 10.0
    if "lc_mould_height" not in st.session_state: st.session_state.lc_mould_height = 12.7
    if "lc_num_points" not in st.session_state: st.session_state.lc_num_points = 5
    if "lc_trial_inputs" not in st.session_state:
        st.session_state.lc_trial_inputs = [{"W1":0.0,"W2":0.0,"W3":0.0,"W4":0.0,"W5":0.0} for _ in range(st.session_state.lc_num_points)]

    # Number of trials input
    num_points = st.number_input(
        "🔢 Number of Compaction Trials",
        min_value=3, max_value=10,
        value=st.session_state.lc_num_points,
        step=1,
        key="lc_num_points_input"
    )
    if num_points != st.session_state.lc_num_points:
        st.session_state.lc_num_points = num_points
        st.session_state.lc_trial_inputs = [{"W1":0.0,"W2":0.0,"W3":0.0,"W4":0.0,"W5":0.0} for _ in range(num_points)]

    # Mould dimensions
    st.markdown("### 📏 Mould Dimensions")
    col1, col2 = st.columns(2)
    with col1:
        st.session_state.lc_mould_dia = st.number_input(
            "Diameter (cm)", value=st.session_state.lc_mould_dia, min_value=1.0, key="lc_dia"
        )
    with col2:
        st.session_state.lc_mould_height = st.number_input(
            "Height (cm)", value=st.session_state.lc_mould_height, min_value=1.0, key="lc_height"
        )
    volume = (math.pi/4)*st.session_state.lc_mould_dia**2*st.session_state.lc_mould_height
    st.info(f"📐 Volume of Mould = **{volume:.2f} cm³**")

    # Trial data input
    st.markdown("### 📋 Enter Data for Each Trial")
    for i in range(num_points):
        st.markdown(f"#### Trial {i+1}")
        c1, c2 = st.columns(2)
        with c1:
            st.session_state.lc_trial_inputs[i]["W1"] = st.number_input(
                f"W1: Empty Cup (g)", min_value=0.0, value=st.session_state.lc_trial_inputs[i]["W1"], key=f"lc_W1_{i}"
            )
            st.session_state.lc_trial_inputs[i]["W2"] = st.number_input(
                f"W2: Cup + Wet Soil (g)", min_value=0.0, value=st.session_state.lc_trial_inputs[i]["W2"], key=f"lc_W2_{i}"
            )
            st.session_state.lc_trial_inputs[i]["W3"] = st.number_input(
                f"W3: Cup + Dry Soil (g)", min_value=0.0, value=st.session_state.lc_trial_inputs[i]["W3"], key=f"lc_W3_{i}"
            )
        with c2:
            st.session_state.lc_trial_inputs[i]["W4"] = st.number_input(
                f"W4: Mould + Base Plate (g)", min_value=0.0, value=st.session_state.lc_trial_inputs[i]["W4"], key=f"lc_W4_{i}"
            )
            st.session_state.lc_trial_inputs[i]["W5"] = st.number_input(
                f"W5: Mould + Soil + Plate (g)", min_value=0.0, value=st.session_state.lc_trial_inputs[i]["W5"], key=f"lc_W5_{i}"
            )

    # --- Save Inputs ---
    if st.button("💾 Save Inputs", key="save_lc_inputs_button"):
        input_df_data = []
        for i, trial_data in enumerate(st.session_state.lc_trial_inputs):
            row = {
                "Trial": i+1,
                "W1 (g)": trial_data["W1"],
                "W2 (g)": trial_data["W2"],
                "W3 (g)": trial_data["W3"],
                "W4 (g)": trial_data["W4"],
                "W5 (g)": trial_data["W5"],
                "Mould Diameter (cm)": st.session_state.lc_mould_dia,
                "Mould Height (cm)": st.session_state.lc_mould_height
            }
            input_df_data.append(row)
        input_df_to_save = pd.DataFrame(input_df_data)
        buffer = StringIO()
        input_df_to_save.to_csv(buffer, index=False)
        buffer.seek(0)
        st.download_button(
            label="📥 Download Input Data as CSV",
            data=buffer.getvalue(),
            file_name="light_compaction_inputs.csv",
            mime="text/csv"
        )

    # --- Calculate Results ---
    if st.button("Calculate Compaction Results", key="calculate_lc_results_button"):
        calculated_data = []
        for i, trial_input in enumerate(st.session_state.lc_trial_inputs):
            W1 = trial_input["W1"]; W2 = trial_input["W2"]; W3 = trial_input["W3"]
            W4 = trial_input["W4"]; W5 = trial_input["W5"]
            if W1>0 and W2>W1 and W3>W1 and W5>W4:
                try:
                    weight_wet = W2 - W1
                    weight_dry = W3 - W1
                    water_content = ((weight_wet - weight_dry)/weight_dry)*100
                    wet_density = (W5 - W4)/volume
                    dry_density = wet_density/(1 + water_content/100)
                    calculated_data.append({
                        "Trial": i+1,
                        "Water Content (%)": round(water_content,2),
                        "Wet Density (g/cc)": round(wet_density,3),
                        "Dry Density (g/cc)": round(dry_density,3)
                    })
                except:
                    st.warning(f"Trial {i+1}: Error in calculation. Check inputs.")
            else:
                st.warning(f"Trial {i+1}: Incomplete/invalid input. Please check W1-W5.")

        if calculated_data:
            df = pd.DataFrame(calculated_data)
            st.markdown("### 📊 Compaction Results Table")
            st.dataframe(df, use_container_width=True)

            mdd = df["Dry Density (g/cc)"].max()
            omc = df.loc[df["Dry Density (g/cc)"].idxmax(),"Water Content (%)"]

            st.success(f"✅ Maximum Dry Density (MDD) = {mdd:.3f} g/cc")
            st.success(f"✅ Optimum Moisture Content (OMC) = {omc:.2f}%")

            # Plot Compaction Curve
            st.markdown("### 📈 Compaction Curve")
            fig, ax = plt.subplots(figsize=(8,5))
            ax.plot(df["Water Content (%)"], df["Dry Density (g/cc)"], marker='o', color='blue', linestyle='-')
            ax.set_xlabel("Water Content (%)"); ax.set_ylabel("Dry Density (g/cc)")
            ax.set_title("Compaction Curve"); ax.grid(True)
            ax.plot(omc, mdd, 'ro', markersize=8, label=f'OMC ({omc:.2f}%), MDD ({mdd:.3f} g/cc)')
            ax.vlines(omc, ax.get_ylim()[0], mdd, color='red', linestyle='--', linewidth=0.7)
            ax.hlines(mdd, ax.get_xlim()[0], omc, color='red', linestyle='--', linewidth=0.7)
            ax.legend(); st.pyplot(fig)

            img_buf = BytesIO(); fig.savefig(img_buf, format="png", bbox_inches="tight"); img_buf.seek(0); plt.close(fig)

            # IS Code Suitability
            suitability_remark = ""
            st.markdown("### ✅ Suitability Based on IS Code")
            if mdd>1.8:
                suitability_remark = "Suitable for base/subgrade (high compaction)."; st.info("🟢 "+suitability_remark)
            elif 1.6<=mdd<=1.8:
                suitability_remark = "Moderately compacted. Acceptable for fill layers."; st.info("🟡 "+suitability_remark)
            else:
                suitability_remark = "Low compaction. Soil may require stabilization."; st.warning("🔴 "+suitability_remark)

            # --- Generate Word Report ---
            if st.button("📄 Generate Word Report"):
                doc = Document()
                doc.add_heading("Light Compaction Test Report", 0)
                doc.add_paragraph(f"Mould Diameter: {st.session_state.lc_mould_dia} cm")
                doc.add_paragraph(f"Mould Height: {st.session_state.lc_mould_height} cm")
                doc.add_paragraph(f"Volume: {volume:.2f} cm³")
                doc.add_paragraph(f"Maximum Dry Density (MDD): {mdd:.3f} g/cc")
                doc.add_paragraph(f"Optimum Moisture Content (OMC): {omc:.2f}%")
                doc.add_paragraph(f"Suitability Remark: {suitability_remark}")

                # Add Compaction Curve plot
                doc.add_heading("Compaction Curve", level=1)
                doc.add_picture(img_buf, width=Inches(6))

                # Add trial data table
                doc.add_heading("Trial Data", level=1)
                table = doc.add_table(rows=1, cols=len(df.columns))
                table.autofit = True
                hdr_cells = table.rows[0].cells
                for idx, col_name in enumerate(df.columns):
                    hdr_cells[idx].text = col_name
                for i in range(len(df)):
                    row_cells = table.add_row().cells
                    for j, col_name in enumerate(df.columns):
                        row_cells[j].text = str(df[col_name].iloc[i])
                buffer_word = BytesIO()
                doc.save(buffer_word)
                buffer_word.seek(0)
                st.download_button(
                    "📥 Download Word Report",
                    data=buffer_word.getvalue(),
                    file_name="Light_Compaction_Test_Report.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                )

            return {
                "Mould Dimensions": pd.DataFrame({"Parameter":["Diameter (cm)","Height (cm)","Volume (cm³)"],
                                                 "Value":[st.session_state.lc_mould_dia,st.session_state.lc_mould_height,volume]}),
                "Test Results Data": df,
                "Maximum Dry Density (MDD)": f"{mdd:.3f} g/cc",
                "Optimum Moisture Content (OMC)": f"{omc:.2f}%",
                "Compaction Curve Graph": img_buf,
                "Suitability Remarks": suitability_remark
            }

        else:
            st.error("⚠ No valid data points to calculate MDD and OMC.")
    return None